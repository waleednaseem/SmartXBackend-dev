const db = require('../models')
const jwt = require('jsonwebtoken')
const { Sequelize } = require('sequelize');
const { sequelize } = require('../models');



const User = db.User
const Refferal = db.Refferal
const Pakage = db.Pakage
const wallet = db.wallet


const FIndUser = async (req, res) => {
  const user = await User.findOne({
    where: { id: req.body.id },
    attributes:['username'],
    include: [
      {
        model: Pakage,
        attributes:['pkg_name','pkg_price'],
      },
      {
        model: Refferal,
        attributes:['refferal'],
        include: [{
          model: User,
          as: 'directReff',
          attributes:['username']
        }]
      }, {
        model: wallet,
        attributes:['payment']
      }]
  })
  res.json(user)
}

const makeUser = async (req, res) => {
  // const salt = await bcrypt.genSalt(10);
  // const hashedPassword = await bcrypt.hash(req.body.password, salt);
  const password = req.body.password;
const hashedPassword = jwt.sign({ password }, 'teriMaaKiChot');
  // const FindReff = await User.findOne({ where: { id: req.body.refferal } })

  const findRight = await User.findOne({
    where: {
      left: { [Sequelize.Op.ne]: null },
      right: null
    }
  });

  if (findRight) {
    // xx-------------------xx------------------------------xx---------------------xxx
    const usermake = await User.create({
      username: req.body.username,
      password: hashedPassword,
      email: req.body.email,
      phone: req.body.phone,
      refferal: req.body.refferal,
      level: findRight.level + 1
    });

    await User.update({
      right: usermake.id
    }, {
      where: {
        id: findRight.id
      }
    });
    await Refferal.create({
      level_id: usermake.level,
      placement_id: findRight.id,
      refferal: req.body.refferal,
      user_id: usermake.id
    });
    const DirectReff = await User.findOne({ where: { id: req.body.refferal } })
    // const pkg = await Pakage.findOne({ where: { user_id: req.body.refferal } })
    const walletpayment = await wallet.findOne({ where: { user_id: req.body.refferal } })
    const admin = await wallet.findOne({ where: { user_id: 1 } })
    await Pakage.create({
      user_id:usermake.id,
      pkg_price:req.body.pkg
    })

    if (req.body.pkg == 3000) {
      await wallet.update({ payment: admin.payment + 300 }, { where: { user_id: 1 } }) // 10% for admin
      await wallet.update({ payment: admin.payment + 2700 }, { where: { user_id: walletpayment.user_id } }) // 90% for user
    } else if (req.body.pkg == 5000) {
      await wallet.update({ payment: admin.payment + 500 }, { where: { user_id: 1 } }) // 10% for admin
      await wallet.update({ payment: walletpayment.payment + 5500 }, { where: { user_id: walletpayment.user_id } }) // 90% for user
    } else if (req.body.pkg == 10000) {
      await wallet.update({ payment: admin.payment + 1000 }, { where: { user_id: 1 } }) // 10% for admin
      await wallet.update({ payment: walletpayment.payment + 9000 }, { where: { user_id: walletpayment.user_id } }) // 90% for user
    }

    const walletx = await wallet.create({
      payment: 0,
      user_id: usermake.id
    })
    res.status(200).json({ msg: 'from Right', data: findRight, DirectReff, walletx });
    // xx-------------------xx------------------------------xx---------------------xxx
  } else {
    const findLeft = await User.findOne({
      where: {
        left: null
      }
    });
    if (findLeft) {
      // xx-------------------xx------------------------------xx---------------------xxx
      const usermake = await User.create({
        username: req.body.username,
        password: hashedPassword,
        email: req.body.email,
        phone: req.body.phone,
        refferal: req.body.refferal,
        level: findLeft.level + 1
      });

      await User.update({
        left: usermake.id
      }, {
        where: {
          id: findLeft.id
        }
      });
      await Refferal.create({
        level_id: usermake.level,
        placement_id: findLeft.id,
        refferal: req.body.refferal,
        user_id: usermake.id
      });
      const DirectReff = await User.findOne({ where: { id: req.body.refferal } })
      // const pkg = await Pakage.findOne({ where: { user_id: req.body.refferal } })
      const walletpayment = await wallet.findOne({ where: { user_id: req.body.refferal } })
      const admin = await wallet.findOne({ where: { user_id: 1 } })
      await Pakage.create({
        user_id:usermake.id,
        pkg_price:req.body.pkg
      })

      if (req.body.pkg == 3000) {
        await wallet.update({ payment: admin.payment + 300 }, { where: { user_id: 1 } }) // 10% for admin
        await wallet.update({ payment: walletpayment.payment + 2700 }, { where: { user_id: walletpayment.user_id } }) // 90% for user
      } else if (req.body.pkg == 5000) {
        await wallet.update({ payment: admin.payment + 500 }, { where: { user_id: 1 } }) // 10% for admin
        await wallet.update({ payment: walletpayment.payment + 5500 }, { where: { user_id: walletpayment.user_id } }) // 90% for user
      } else if (req.body.pkg == 10000) {
        await wallet.update({ payment: admin.payment + 1000 }, { where: { user_id: 1 } }) // 10% for admin
        await wallet.update({ payment: walletpayment.payment + 9000 }, { where: { user_id: walletpayment.user_id } }) // 90% for user
      }

      const walletx = await wallet.create({
        payment: 0,
        user_id: usermake.id
      })
      res.status(200).json({ msg: 'from Left', data: findLeft, DirectReff, walletx });
      // xx-------------------xx------------------------------xx---------------------xxx
    } else {
      const usermake = await User.create({
        username: req.body.username,
        password: hashedPassword,
        email: req.body.email,
        phone: req.body.phone,
        level: 0,
      });
      const walletx = await wallet.create({
        payment: 0,
        user_id: usermake.id
      })
      res.status(200).json({ msg: 'no space found', usermake, walletx });
    }
  }
}

const Login = async (req, res) => {
  const user = await User.findOne({
    where: {
      username: req.body.username
    }
  })

  if (!user) {
    return res.status(200).send('User not found')
  }

  // const validPassword = await bcrypt.compare(req.body.password, user.password)
  const token = jwt.sign(payload, 'teriMaaKiChot');

  if (!token) {
    return res.status(401).send('Invalid password')
  }
  const payload = {
    id: user.id
  };
  console.log(user.id)
  try {
    
    res.status(200).send({ message: 'Logged in successfully', token });
  } catch (err) {
    res.status(500).send({ message: 'Error creating token' });
  }
}

const userDetail = async (req, res) => {
  const user = await User.findByPk(req.body.id)
  res.status(200).send(user)
}

const showusers = async (req, res) => {

  const referral = await Refferal.findAll({
    where: { refferal: req.body.refferal },
    include: [{
      model: User,
      as: 'ReffUsers',
    }],
  });
  res.status(200).send(referral)
}

const refferals = async (req, res) => {
  // const user = await User.findAll()
  const user = await User.findAll({
    where: { id: req.body.id },
    attributes: ['id', 'username', 'phone', 'email'],
    include: [{
      model: Refferal,
      attributes: ['id', 'placement_id', 'level_id', 'refferal', 'user_id'],
      include: [{
        model: User,
        attributes: ['id', 'username', 'phone', 'email'],
        include: [{
          model: Refferal,
          attributes: ['id', 'placement_id', 'level_id', 'refferal', 'user_id'],
          include: [{
            model: User,
            attributes: ['id', 'username', 'phone', 'email'],
            include: [{
              model: Refferal,
              attributes: ['id', 'placement_id', 'level_id', 'refferal', 'user_id'],
              include: [{
                model: User,
                attributes: ['id', 'username', 'phone', 'email'],
                include: [{
                  model: Refferal,
                  attributes: ['id', 'placement_id', 'level_id', 'refferal', 'user_id'],
                  include: [{
                    model: User,
                    attributes: ['id', 'username', 'phone', 'email'],
                    include: [{
                      model: Refferal,
                      attributes: ['id', 'placement_id', 'level_id', 'refferal', 'user_id'],
                      include: [{
                        model: User,
                        attributes: ['id', 'username', 'phone', 'email'],
                        include: [{
                          model: Refferal,
                          attributes: ['id', 'placement_id', 'level_id', 'refferal', 'user_id'],
                          include: [{
                            model: User,
                            attributes: ['id', 'username', 'phone', 'email'],
                            include: [{
                              model: Refferal,
                              attributes: ['id', 'placement_id', 'level_id', 'refferal', 'user_id'],
                              include: [{
                                model: User,
                                attributes: ['id', 'username', 'phone', 'email'],
                                include: [{
                                  model: Refferal,
                                  include: [{
                                    model: User
                                  }]
                                }]
                              }]
                            }]
                          }]
                        }]
                      }]
                    }]
                  }]
                }]
              }]
            }]
          }]
        }]
      }]
    }]
  })
  res.status(200).send(user)
}

const placementInvest = async (req, res) => {
  const user = await User.findOne({ where: { id: req.body.id }, include: [{ model: Refferal, as: 'Refferal', include: [{ model: User, as: 'directReff' }] }] })

  const placements = [];
  let placement = await User.findOne({

    // attributes: ['username', 'email', 'phone', 'left', 'right', 'level'],
    where: {
      [Sequelize.Op.or]: [{ left: user.id }, { right: user.id }],
    },
    include: [{ model: Pakage, attributes: ['pkg_name', 'pkg_price'] }]

  })
  if (!placement) {
    placements.push(null);
  } else {
    placements.push(placement);
  }

  for (let i = 2; i <= 8; i++) {
    if (!placement) {
      break;
    }
    placement = await User.findOne({
      // attributes: ['username', 'email', 'phone', 'left', 'right', 'level'],
      where: {
        [Sequelize.Op.or]: [{ left: placement.id }, { right: placement.id }]
      }, include: [{ model: Pakage, attributes: ['pkg_name', 'pkg_price'] }]
    })
    if (!placement) {
      placements.push(null);
    } else {
      placements.push(placement);
    }
  }

  res.status(200).json({
    placements
  });
}

const ShowReff = async (req, res) => {
  const user = await User.findOne({
    where: { id: req.body.id },
    attributes: ['username', 'left', 'right'],
    include: [{
      model: Refferal,
      as: 'left_placement',
      attributes: ['refferal', 'user_id', 'level_id', 'placement_id'],

    }, {
      model: Refferal,
      as: 'right_placement',
      attributes: ['refferal', 'user_id', 'level_id', 'placement_id'],

    }]
  });
  res.status(200).json(user)
};
const getUserByTrend = async (req, res) => {
  const UserID = req.params.userId

  const user = await User.findByPk(UserID, {
    include: [{
      model: Refferal,
      as: 'left_placement',
      attributes: ['refferal', 'user_id', 'level_id', 'placement_id'],

    }, {
      model: Refferal,
      as: 'right_placement',
      attributes: ['refferal', 'user_id', 'level_id', 'placement_id'],

    }]
  })
  res.status(200).json(user)
}

const wallets = async (req, res) => {
  const Walletx = await User.findOne({
    where: { id: req.body.id },
    attributes: ['username', 'email', 'phone', 'left', 'right', 'level'],
    include: [{
      model: wallet,
      attributes: ['payment']
    }]
  })
  res.json(Walletx)
}

const UserUpgrade = async (req, res) => {

  const user = await User.findOne({ where: { id: req.body.id }, include: [{ model: Refferal, as: 'Refferal', include: [{ model: User, as: 'directReff' }] }] })

  const placement = await User.findOne({
    where: {
      [Sequelize.Op.or]: [{ left: user.id }, { right: user.id }]
    }
  })

  res.status(200).json({ direct: user, place1: placement })
}

const levelFromTable = async (req, res) => {

  const refferals = await Refferal.findAll({
    where: { level_id: 2 },
    include: [{
      model: User,
    }]
  })

  res.status(200).json(refferals)
}

const FindUserTransac=async(req,res)=>{

}

const decode = async(req, res) => {
  try {
    const user = await User.findOne({where:{id:req.body.id}});
    const userDecode = await jwt_decode(user.password);
    res.json({user: userDecode});
  } catch (err) {
    console.log(err);
    res.status(500).send('Internal Server Error');
  }
}



module.exports = {
  makeUser,
  Login,
  userDetail,
  showusers,
  placementInvest,
  refferals,
  levelFromTable,
  UserUpgrade,
  ShowReff,
  getUserByTrend,
  wallets,
  FIndUser,
  FindUserTransac,
  decode
}